package io.github.proyecto1.Util;

public class Estados {
    public static enum EstadoMovimiento {
        SUBIENDO, BAJANDO, PARADO,IZQUIERDA,DERECHA
    }
}
