
package fotografiahb25;

public class Fotografiahb25 {

    public static void main(String[] args) {
    }
}
