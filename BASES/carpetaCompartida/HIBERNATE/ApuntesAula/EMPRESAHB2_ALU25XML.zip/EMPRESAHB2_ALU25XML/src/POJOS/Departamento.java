package POJOS;
// Generated 09-feb-2023 8:57:23 by Hibernate Tools 3.6.0


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;


public class Departamento  implements java.io.Serializable {


     private int numDepartamento;
     private String nomeDepartamento;
    

    public Departamento() {
    }

    public int getNumDepartamento() {
        return numDepartamento;
    }

    public void setNumDepartamento(int numDepartamento) {
        this.numDepartamento = numDepartamento;
    }

    public String getNomeDepartamento() {
        return nomeDepartamento;
    }

    public void setNomeDepartamento(String nomeDepartamento) {
        this.nomeDepartamento = nomeDepartamento;
    }

   
  




}


